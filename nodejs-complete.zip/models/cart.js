const fs =  require('fs');
const path =  require('path');
const getDB =  require('../utils/database').getDB;
const mongodb = require('mongodb');

const p =  path.join(path.dirname(process.mainModule.filename),'data','cart.json');

module.exports=class Cart{

    constructor(title, price,imageUrl, description,id) {
        this.title = title;
        this.price = price;
        this.imageUrl = imageUrl;
        this.description = description;
        this._id = new mongodb.ObjectId(id) ;
    }

    save() {

        getDB().collection('cart').findOne({_id:this._id}).then(res=>{
            if(res){
               this.qty = res.qty+1;
               getDB().collection('cart').updateOne({ _id : this._id}, { $set: this }).then(res => res).
               catch(err => console.log(err));
            }
            else{
                this.qty = 1;
                const db = getDB();
                return db.collection('cart').insertOne(this).
                then(result => result).
                catch(err => console.log(err))
            }
            
        })

    }

    static deleteItem(id){
      
        return getDB().collection('cart').deleteOne({_id : new mongodb.ObjectID(id)}).
        then(result => {
            console.log('Dleted cart item');
            return result;
        }).
        catch(err => console.log(err));
    }

    static fetchCartProducts() {

        return getDB().collection('cart').find().toArray().
            then(result => {
                console.log('fetching data..');
                return result;
            }).
            catch(err => console.log(err));

    }

   

    static addProduct(id,price){
       
        fs.readFile(p,(err,fileContent)=>{
             
            let carts = { products : [], totalPrice : 0 };
            if(!err){
                carts = JSON.parse(fileContent);
            }
            const index = carts.products.findIndex(product => product.id === id);
            const existingProduct =  carts.products[index];
            
            if(existingProduct){
                 carts.products[index].qty = carts.products[index].qty + 1;
            }
            else{
                let updatedProduct = { id : id , qty : 1};
                carts.products = [...carts.products , updatedProduct];
            }
            carts.totalPrice = +carts.totalPrice + +price;

            fs.writeFile(p,JSON.stringify(carts),(err)=>{
                console.log(err);
            })
        })

    }

    static getCart()
    {
        return  getDB().collection('product').find().toArray().then(res=>res).catch(err=>console.log(err));
    }

    static deleteCartProduct(id,price,resp){
       
        fs.readFile(p,(err,fileContent)=>{
            const carts = JSON.parse(fileContent);
            const index =  carts.products.findIndex(c => c.id == id);
            carts.totalPrice = carts.products[index].qty *price;
            carts.products = carts.products.filter(p=> p.id != id);
            console.log('cart delete product function...');
            fs.writeFile(p,JSON.stringify(carts),(err)=>{
                console.log(err);
            })
            return resp('deleted from cart');
        })
    }
}