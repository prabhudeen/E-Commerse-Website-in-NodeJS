const getDB = require('../utils/database').getDB;
const mongo = require('mongodb');

 class User{
     constructor(userName, email,cart,id){
         this.userName=userName;
         this.email=email;
         this.cart = cart;
         this._id = id ? new mongo.ObjectId(id) :null; 
     }

     save(){

        return getDB().collection('user').insertOne(this);
     }

     static findById(id){
         return getDB().collection('user').findOne({_id: new mongo.ObjectID(id)});
     }
}

module.exports = User;