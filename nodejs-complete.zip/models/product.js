const rootPath = require('../utils/path');
const path = require('path');
const fs = require('fs');
const Cart = require('../models/cart');
const getDB = require('../utils/database').getDB;
const mongodb = require('mongodb');
module.exports = class Product {

    constructor(title, price,imageUrl, description, id) {
        this.title = title;
        this.price = price;
        this.imageUrl = imageUrl;
        this.description = description;
        this._id = id ? new mongodb.ObjectId(id) : null;
    }

    save() {

        if (this._id) {
            return getDB().collection('product').updateOne({ _id : this._id}, { $set: this }).then(res => res).
                catch(err => console.log(err));
        }
        else {
               const db = getDB();
                return db.collection('product').insertOne(this).
                then(result => result).
                catch(err => console.log(err));
        }

    }

    static fetchAllProducts() {

        return getDB().collection('product').find().toArray().
            then(result => {
                console.log('fetching data..');
                return result;
            }).
            catch(err => console.log(err));

    }

    static findById(id) {
        return getDB().collection('product').find({ _id: new mongodb.ObjectID(id) }).next().
            then(result => {
                console.log('find by  Id ...' + result);
                return result;
            }).catch(err => { throw err });
    }

    

    static deleteById(id) {

       return getDB().collection('product').deleteOne({_id:new mongodb.ObjectID(id)}).
              then(result=> console.log(result)).
              catch(err=>console.log(err));
    }

    static getproduct(id){

        return getDB().collection('product').find({ _id: new mongodb.ObjectID(id) }).next().
        then(result => {
            console.log('find by  Id ...' + result);
            return result;
        }).catch(err => { throw err });
    }


}