const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const http = require('http');
const adminRouter = require('./Routes/admin');
const shopRouter = require('./Routes/shop');
const mongoConnect = require('./utils/database').mongoConnect;
const mongoose = require('mongoose');
// const expressHbs =  require('express-handlebars');

const app = express();

// app.engine('hbs',expressHbs({layoutsDir:'Views/layouts/',defaultLayout:'main-layout' ,extname:'hbs'}));
app.set('view engine', 'ejs');
app.set('views', 'Views');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/admin', adminRouter);
app.use(shopRouter);

app.use('/', (req, res, next) => {

    res.status(404).render('404', { path: '', docTitle: 'Page Not Found' });
});

mongoConnect((client) => {
    console.log('started server...')
    console.log(client);
    app.listen(3000);
})














// const express = require('express');
// const mongoose = require('mongoose');
// const MongoClient = require('mongodb').MongoClient;
// const uri = "mongodb+srv://root:root@cluster0-9ivfe.mongodb.net/test?retryWrites=true";


// mongoose.connect(uri,{useNewUrlParser:true}).then(result=>{
//     console.log('connnected...',result);

// }).catch(err=>console.log(err));