const mongodb = require('mongodb');
const MongodbClient = mongodb.MongoClient;

let _db;
const mongoConnect = (callback) => {
    MongodbClient.connect('mongodb+srv://root:root@cluster0-9ivfe.mongodb.net/shop?retryWrites=tru', { useNewUrlParser: true }).
        then(client => {
            _db = client.db();
            console.log('connnected...');
            return callback(client);
        }).
        catch(err => {
            console.log(err);
            throw err;
        });
}

const getDB = () => {
    if (_db) {
        return _db;
    }
    throw 'No Database Connected...';
}

exports.mongoConnect = mongoConnect;
exports.getDB = getDB;