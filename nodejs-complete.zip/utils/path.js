const path = require('path');

const rootDir=path.dirname(process.mainModule.filename);

module.exports = rootDir;