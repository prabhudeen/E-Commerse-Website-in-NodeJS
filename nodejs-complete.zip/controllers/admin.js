const Product = require('../models/product');
const mongodb = require('mongodb');
exports.getAddProduct = (req, res, next) => {
    res.status(202).render('admin/edit-product', 
                          { docTitle: 'Add Product',
                           path: '/admin/add-product',
                           productType: true,
                           editing:false 
                          });
}

exports.getEditProduct=(req,res,next)=>{

    const id=req.params.id;
    const editing =  req.query.edit;
    if(!editing){
        return res.redirect('/');
    }
    Product.findById(id).then(product=>{

        const prod =  product;
        if(!product){
            return res.redirect('/');
        }
        res.render('admin/edit-product',
        { docTitle: 'Add Product',
          path: '/admin/edit-product',
          productType: true,
          editing:editing,
          product:prod
       });
    }).catch(err=>console.log(err));
}

exports.postEditProduct = (req,res,next)=>{
  
    const id= req.body.id;
    const title =req.body.title;
    const imageUrl =req.body.imageUrl;
    const price =req.body.price;
    const description = req.body.description;
    console.log(id);
    const product = new Product(title,price,imageUrl,description,id);
    product.save().then(result=>{
        res.redirect('/');
    }).catch(err=>console.log(err));
    
}

exports.postAddProduct = (req, res, next) => {

    const title = req.body.title;
    const imageUrl = req.body.imageUrl;
    const price = req.body.price;
    const description = req.body.description;
    const product = new Product(title, price,imageUrl, description,null);
    product.save().
    then(result=>{
        console.log('Added Product...'+result);
        res.status(202).redirect('/');
      }).
    catch(err=>console.log('Error while adding product...'));
  
}

exports.getProducts = (req, res, next) => {
    Product.fetchAllProducts().then(products => {
        res.status(202).render('admin/products', {
            prods: products,
            docTitle: 'Admin Products',
            path: '/admin/products'
        })
    }).catch(err=>console.log(err));
    

}

exports.postDeleteProduct = (req,res,next)=>{
    const id = req.body.productId;
 
    Product.deleteById(id).then(resp=>{
        
        res.redirect('/admin/products');
    }).catch(err=>console.log(err));


}
