const Product = require('../models/product');
const Cart = require('../models/cart');

exports.getProducts = (req,res,next)=>{
     Product.fetchAllProducts().then(prods=>{
        const products = prods;
        console.log('Admin Data in Shop File.. ',products);
        res.render('shop/product-list',
        {prods:products,
         docTitle:'All Products',
         path:'/products'}); 
    }).catch(err=>console.log(err));

}

    exports.getIndex = (req,res,next)=>{

        Product.fetchAllProducts().
        then(
            product=>{
                const products = product;
                res.render('shop/index',
                            {prods:products,
                            docTitle:'Shop',
                            path:'/'}); 
            }
        ).catch(err=>console.log(err));
   
}

exports.postDeleteCartItem=(req,res,next)=>{

    const id = req.body.productId;
    Cart.deleteItem(id).then(result=>{
        if(result)  res.redirect('/cart');
    })
}

exports.getCart = (req,res,next)=>{
   
    Cart.fetchCartProducts().then(data =>{
        const cartData = data;
                    res.render('shop/cart',
                    {
                    docTitle:'Cart',
                    path:'/cart',
                    data:cartData,
                    total:100
                    });
        
    }).catch(err=>console.log(err)); 

}  

exports.postCart = (req,res,next)=>{

    const id=req.body.productId;
  
    Product.getproduct(id).then(product =>{
        const prod = product;
        const cartItem = new Cart(prod.title, prod.price,prod.imageUrl, prod.description,prod._id);
        cartItem.save();
        res.redirect('/cart');
    })
           
    
    
   

}

exports.getCheckout = (req,res,next)=>{
    
       res.render('shop/checkout',
                {
                docTitle:'Checkout',
                path:'/checkout'}); 
             
}

exports.postOrder = (req,res,next)=>{
    var stripe = require("stripe")("sk_test_FfOhF8PjfmWkhFrJIfHQ08Ww00xYmHYs0w");

    // Token is created using Checkout or Elements!
    // Get the payment token ID submitted by the form:
    const token = req.body.stripeToken; // Using Express
    
    (async () => {
      const charge = await stripe.charges.create({
        amount: 999,
        currency: 'usd',
        description: 'Example charge',
        source: token,
      });
      console.log(charge);
   
    })().then(result=>{
            console.log(result);
            res.write("<html><body>Your Payment Success....</body></html>")
          }).catch(err=>console.log(err));
}





exports.getOrders=(req,res,next)=>{
    
    Product.fetchAllProducts(product=>{
        const products=product;
        res.render('shop/orders',{prods:products,docTitle:'Your Orders' ,path:'/orders'});

        
    });
}

exports.getproduct=(req,res,next)=>{
    
    const id=req.params.id;
    Product.findById(id).then(prod=>{
        const product=prod;
        res.render('shop/product-detail',{prods:product,docTitle:'Detail',path:'/products'});
   }).
   catch(err=>console.log(err));
}