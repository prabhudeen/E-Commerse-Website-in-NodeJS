console.log(__dirname);
const path = require('path');

console.log(`the file name is ${path.basename(__filename)}`);
